from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)
model = joblib.load("rockfall_model.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    values = [[
        float(data["rainfall"]),
        float(data["slope"]),
        float(data["crack"]),
        float(data["moisture"]),
        float(data["temperature"])
    ]]

    columns = ["rainfall", "slope", "crack", "moisture", "temperature"]
    df = pd.DataFrame(values, columns=columns)

    risk = model.predict(df)[0]
    probabilities = model.predict_proba(df)[0]
    score = round(max(probabilities) * 100)

    message = {
        "LOW": "Conditions are relatively stable.",
        "MEDIUM": "Monitor the mine slope carefully.",
        "HIGH": "Immediate attention is recommended."
    }[risk]

    return jsonify({
        "risk": risk,
        "score": score,
        "message": message
    })

if __name__ == "__main__":
    app.run(debug=True)
