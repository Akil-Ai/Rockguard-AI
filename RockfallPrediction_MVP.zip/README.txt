ROCKGUARD AI - MVP

1. Open CMD in this folder.
2. Install packages:
   py -m pip install -r requirements.txt

3. Train the model:
   py train_model.py

4. Start the website:
   py app.py

5. Open in Chrome:
   http://127.0.0.1:5000

Test values:
Rainfall = 80
Slope = 65
Crack = 8
Moisture = 80
Temperature = 34

This is an MVP/prototype for demonstration. The training data is synthetic and should not be used for real mine safety decisions.
