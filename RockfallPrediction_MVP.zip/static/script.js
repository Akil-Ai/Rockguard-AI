async function predictRisk() {
    const result = document.getElementById("result");
    const risk = document.getElementById("risk");
    const score = document.getElementById("score");
    const message = document.getElementById("message");

    const payload = {
        rainfall: document.getElementById("rainfall").value,
        slope: document.getElementById("slope").value,
        crack: document.getElementById("crack").value,
        moisture: document.getElementById("moisture").value,
        temperature: document.getElementById("temperature").value
    };

    try {
        const response = await fetch("/predict", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        risk.textContent = data.risk;
        score.textContent = "Confidence: " + data.score + "%";
        message.textContent = data.message;

        risk.style.color =
            data.risk === "HIGH" ? "#ff4d6d" :
            data.risk === "MEDIUM" ? "#ffd166" : "#62ff9a";

    } catch (error) {
        risk.textContent = "ERROR";
        score.textContent = "Server not connected";
        message.textContent = "Make sure 'py app.py' is running.";
    }
}
